# IR-Remote
Simple Android IR-Remote for my Samsung TV and Samsung Soundbar

<img width="200px" src="screenshot.png" />
